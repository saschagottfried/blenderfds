# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####
"""BlenderFDS, an open tool for the NIST Fire Dynamics Simulator."""

bl_addon_info = {
    "name": "BlenderFDS",
    "author": "Emanuele Gissi",
    "version": "0.50",
    "blender": (2, 5, 3),
    "category": "Export",
    "location": "File > Export > FDS Case (.fds)",
    "description": "BlenderFDS, an open tool for the NIST Fire Dynamics Simulator",
    "wiki_url": "http://www.blenderfds.org/",
    "tracker_url": "http://code.google.com/p/blenderfds/issues/list",
    "category": "Import/Export",
}

import bpy

def register():
    from blenderfds import bf_ui
    
    # scene properties

    bpy.types.Scene.bf_case_dir = bpy.props.StringProperty(
                                   name="Case Dir",
                                   subtype="DIR_PATH",
                                   description="FDS case directory")
   
    bpy.types.Scene.bf_case_title = bpy.props.StringProperty(
                                   name="TITLE",
                                   maxlen=32,
                                   description="Case title")
    
    bpy.types.Scene.bf_voxel_size = bpy.props.FloatVectorProperty(
                                        name="Voxel Size",
                                        description="Voxel size",
                                        step=1, precision=3,
                                        subtype="XYZ",
                                        default=(.20, .20, .20),
                                        min=.001, max=10.)

    items_list = [("auto", "Auto Header", "Automatic header"),
                  ("file", "File", "Custom header file",)]
    bpy.types.Scene.bf_type_of_header = bpy.props.EnumProperty(
                                 name="Type of Header",
                                 items=items_list,
                                 description="Type of header",
                                 default="automatic")
                                 
    bpy.types.Scene.bf_header_file_path = bpy.props.StringProperty(
                                   name="Header File",
                                   subtype="FILE_PATH",
                                   description="Header file",
                                   default="header.fds")
                                   
    # object properties
    
    bpy.types.Object.bf_nl_export = bpy.props.BoolProperty(
                                  name="Export",
                                  description="Export object to FDS",
                                  default=False)
   
    bpy.types.Object.bf_nl_name = bpy.props.StringProperty(
                                    name="& Name",
                                    description="Namelist name",
                                    default="OBST")

    bpy.types.Object.bf_id = bpy.props.BoolProperty(
                                  name="ID",
                                  description="Set ID parameter",
                                  default=True)
                                  
    items_list = [("none",   "None",   "None"),
                  ("voxels", "Voxels", "Voxelized solid"),
                  ("bbox",   "BBox",   "Bounding box"),
                  ("faces",  "Faces",  "Faces, one for each face of this object"),
                  ("edges",  "Edges",  "Segments, one for each edge of this object")]
    bpy.types.Object.bf_xb = bpy.props.EnumProperty(
                                  name="XB",
                                  items=items_list,
                                  description="Set XB parameter",
                                  default="none")
    
    items_list = [("none",   "None",   "None"),
                  ("center", "Center", "Point, corresponding to center point of this object"),
                  ("verts",  "Verts",  "Points, one for each vertex of this object"),]
    bpy.types.Object.bf_xyz = bpy.props.EnumProperty(
                                  name="XYZ",
                                  items=items_list,
                                  description="Set XYZ parameter",
                                  default="none")
    
    items_list = [("none",   "None",   "None"),
                  ("faces",  "Faces",  "Planes, one for each face of this object"),]
    bpy.types.Object.bf_pb = bpy.props.EnumProperty(
                                  name="PB*",
                                  items=items_list,
                                  description="Set PBX, PBY, PBZ parameter",
                                  default="none")

    bpy.types.Object.bf_cell_size = bpy.props.FloatVectorProperty(
                                         name="Cell Size",
                                         description="Cell size",
                                         step=1, precision=3,
                                         subtype="XYZ",
                                         default=(.20, .20, .20), min=.001, max=10.)
    
    bpy.types.Object.bf_surf_id = bpy.props.BoolProperty(
                                  name="SURF_ID",
                                  description="Set SURF_ID parameter to corresponding Blender material",
                                  default=False)
    
    bpy.types.Object.bf_sawtooth = bpy.props.BoolProperty(
                                  name="SAWTOOTH",
                                  description="Set SAWTOOTH=.FALSE. parameter",
                                  default=False)
    
    bpy.types.Object.bf_ijk = bpy.props.BoolProperty(
                                  name="IJK",
                                  description="Set IJK parameter optimized for voxel size",
                                  default=False)
    
    bpy.types.Object.bf_fyi = bpy.props.StringProperty(
                                    name="FIY",
                                    maxlen=32,
                                    description="Set FIY parameter")
    
    bpy.types.Object.bf_custom_param = bpy.props.StringProperty(
                                    name="Custom Parameters",
                                    description="Set custom parameters (exported verbatim)")
    
    bpy.types.Object.bf_msg = bpy.props.StringProperty(name="Msg") # error message
    bpy.types.Object.bf_msg_timer = bpy.props.IntProperty(name="Timer") # timer for error message
        
    # material properties
    
    bpy.types.Material.bf_rgb = bpy.props.BoolProperty(
                                    name="RGB",
                                    description="Set RGB parameter to corresponding Blender material diffuse color",
                                    default=True)

    bpy.types.Material.bf_transparency = bpy.props.BoolProperty(
                                    name="TRANSPARENCY",
                                    description="Set TRANSPARENCY parameter to corresponding Blender material alpha",
                                    default=False)
    
    bpy.types.Material.bf_fyi = bpy.props.StringProperty(
                                      name="FIY",
                                      maxlen=32,
                                      description="Set FIY parameter")
                                       
    bpy.types.Material.bf_custom_param = bpy.props.StringProperty(
                                      name="Custom Parameters",
                                      description="Set custom parameters (exported verbatim)")
     
    # panels
    bpy.types.register(bf_ui.SCENE_PT_bf)
    bpy.types.register(bf_ui.OBJECT_PT_bf)
    bpy.types.register(bf_ui.MATERIAL_PT_bf)
    
    # export menu
    bpy.types.register(bf_ui.FdsExporter)
    bpy.types.INFO_MT_file_export.prepend(bf_ui.menu_export)
    
    # tools
    bpy.types.register(bf_ui.VIEW3D_PT_tools_meshedit_bf)
    
    # ops
    bpy.types.register(bf_ui.OBJECT_OT_bf_set_compatible_voxel)

def unregister():
    from blenderfds import bf_ui
    
    # panels
    bpy.types.unregister(bf_ui.SCENE_PT_bf)
    bpy.types.unregister(bf_ui.OBJECT_PT_bf)
    bpy.types.unregister(bf_ui.MATERIAL_PT_bf)

    # export menu
    bpy.types.unregister(bf_ui.FdsExporter)
    bpy.types.INFO_MT_file_export.remove(menu_export)

    # tools
    bpy.types.unregister(bf_ui.VIEW3D_PT_tools_meshedit_bf)

    # ops
    bpy.types.unregister(bf_ui.OBJECT_OT_bf_set_compatible_voxel)
    
if __name__ == "__main__":
    register()
